<?php

namespace App\Http\Controllers;

use App\Models\Pembayaran;
use App\Models\Post;
use Illuminate\Http\Request;

class PembayaranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get posts
        $posts = Pembayaran::latest()->paginate(5);

        //render view with posts
        return view('pembayarans.index', compact('posts'));
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {        
        $posts = Post::latest()->paginate(5);
        $siswa = Post::all();
        return view('pembayarans.create', compact('posts'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //validate form
      $this->validate($request, [
        'id_siswa'     => 'required',
        'tgl_bayar' => 'required',
        'jumlah_bayar' =>'required',
    ]);
    Pembayaran::create([
        'id_siswa'     => $request->id_siswa,
        'tgl_bayar'     => $request->tgl_bayar,
        'jumlah_bayar'   => $request->jumlah_bayar
    ]);
    
    // $dataT = [
    //             'id_siswa'      => $request->id_siswa,
    //             'tanggal_bayar'     => $request->tanggal_bayar,
    //             'jumlah_bayar'   => $request->jumlah_bayar,
    // ];

    // Pembayaran::create($dataT);
    // dd($dataT);  
    //create post
    // Pembayaran::create([
    //     'id_siswa'      => $request->id_siswa,
    //     'tgl_bayar' => $request->tgl_bayar,
    //     'jumlah_bayar'   => $request->jumlah_bayar,
    // ]);

    //redirect to index
    return redirect()->route('pembayaran.index')->with(['success' => 'Data Berhasil Disimpan!']);

/**
 * Display the specified resource.
 *
 * @param  int  $id
 * @return \Illuminate\Http\Response
 */

    }
    
    /**
     * edit
     *
     * @param  mixed $post
     * @return void
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('pembayarans.edit', compact('posts'));    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,string $id)
    {   // ]);
        $posts = Pembayaran::find($id);
        $posts->id_siswa = $request->id_siswa;
        $posts->tanggal_bayar = $request->tanggal_bayar;
        $posts->jumlah_bayar = $request->jumlah_bayar;
        $posts->update($request->all());
        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pembayaran $pembayaran)
    {
        $pembayaran->delete();

        //redirect to index
        return redirect()->route('pembayaran.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}