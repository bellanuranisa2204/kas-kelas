<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{    
    /**
     * index
     *
     * @return void
     */
    public function index()
    {
        //get posts
        $posts = Post::latest()->paginate(5);

        //render view with posts
        return view('posts.index', compact('posts'));
    }
    
    /**
     * create
     *
     * @return void
     */
    public function create()
    {
        return view('posts.create');
    }

    /**
     * store
     *
     * @param Request $request
     * @return void
     */
    public function store(Request $request)
    {
        // //validate form
        // $this->validate($request, [
        //     'title'     => 'required|min:5',
        //     'content'   => 'required|min:10'
        // ]);

        $siswa= new Post();
        $siswa->nama= $request->nama;
        $siswa->kelas= $request->kelas;
        $siswa->save();
    

        // //create post
        // Post::create([
        //     'nama'     => $request->nama,
        //     'kelas'   => $request->kelas
        // ]);

        //redirect to index
        return redirect()->route('posts.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }
    
    /**
     * edit
     *
     * @param  mixed $post
     * @return void
     */
    public function edit(Post $post)
    {
        return view('posts.edit', compact('post'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $post
     * @return void
     */
    public function update(Request $request, string $id)
    {
        // //validate form
        // $this->validate($request, [

        //     'nama'     => 'required',
        //     'kelas'   => 'required'
        // ]);

            //update post without image
            $Post = Post::find($id);
            $Post->nama = $request->nama;
            $Post->kelas = $request->kelas;

            $Post->update($request->all());
            // dd($Post);

        //redirect to index
        return redirect()->route('posts.index')->with(['success' => 'Data Berhasil Diubah!']);
    }
    
    /**
     * destroy
     *
     * @param  mixed $post
     * @return void
     */
    public function destroy(Post $post)
    {
        //delete image
        Storage::delete('public/posts/'. $post->image);

        //delete post
        $post->delete();

        //redirect to index
        return redirect()->route('posts.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}