<?php

use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\PostController;
use \App\Http\Controllers\PembayaranController;

// Route::get('/', function () {
//     return view('welcome');
// });

//route resource
Route::resource('/', \App\Http\Controllers\HomeController::class);
Route::resource('/posts', \App\Http\Controllers\PostController::class);
Route::resource('/pembayaran', PembayaranController::class);